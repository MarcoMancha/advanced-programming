#include "header.h"

void sos() {
	int semid, shmid, i, j, k, blk_size, tamanio;
	key_t key;
	struct buffer *b;

	if ( (key = ftok("/dev/null", 200)) == (key_t) -1 ) {
		perror("ftok");
		exit(-1);
	}

	if ( (semid = semget(key, 3, 0666))  < 0 ) {
		perror("semget");
		exit(-1);
	}

	if ( (shmid = shmget(key, sizeof(struct buffer), 0666)) < 0 ) {
		perror("shmid");
		exit(-1);
	}
	b = (struct buffer *) shmat(shmid, (void *) 0, 0);

	srand(getpid());
	while(1) {
  	i = rand() % 3;
		sem_wait(semid, BENJI);
    if (i == 0) {
			sem_signal(semid, TWENTY);
			sem_signal(semid, FIFTY);
    } else if (i == 1) {
			sem_signal(semid, TWENTY);
			sem_signal(semid, CENT);
    } else if (i == 2) {
			sem_signal(semid, CENT);
			sem_signal(semid, FIFTY);
    }
  	sleep(5);
	}
	shmdt(b);
	exit(0);
}

int main(int argc, char* argv[]) {
	int amount = 0, semid, i, pid;
	key_t key;

	if (argc != 1) {
		printf("usage: %s\n", argv[0]);
		return -1;
	}

	sos();
	return 0;
}
