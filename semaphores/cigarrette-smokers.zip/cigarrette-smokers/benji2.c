#include "header.h"

void benji() {
	int semid, shmid, i, j, k, blk_size, tamanio;
	key_t key;
	struct buffer *b;

	if ( (key = ftok("/dev/null", 200)) == (key_t) -1 ) {
		perror("ftok");
		exit(-1);
	}

	if ( (semid = semget(key, 3, 0666))  < 0 ) {
		perror("semget");
		exit(-1);
	}

	if ( (shmid = shmget(key, sizeof(struct buffer), 0666)) < 0 ) {
		perror("shmid");
		exit(-1);
	}
	b = (struct buffer *) shmat(shmid, (void *) 0, 0);

	srand(getpid());
	while(1) {
		printf("Benji ha despertado\n");
		printf("Benji esperando a que desocupen el de 50\n");
		sem_wait(semid, FIFTY);
		mutex_wait(semid, MUTEX);
			if(b -> isTwenty == 0){
				b -> isTwenty -= 1;
				sem_signal(semid, CENT);
			}else if(b -> isFifty == 0){
				b -> isFifty -= 1;
				sem_signal(semid, TWENTY);
			}else{
				printf("Benji ha puesto billete de 50\n");
				b -> isFifty += 1;
			}
		mutex_signal(semid, MUTEX);
  	printf("Benji irá a dormir\n\n");
  	sleep(5);
	}
	shmdt(b);
	exit(0);
}

int main(int argc, char* argv[]) {
	int amount = 0, semid, i, pid;
	key_t key;

	if (argc != 1) {
		printf("usage: %s\n", argv[0]);
		return -1;
	}

	benji();
	return 0;
}
