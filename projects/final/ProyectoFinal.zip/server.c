/*----------------------------------------------------------------
*
* Programación avanzada: Proyecto Final
* Fecha: 6-Noviembre-2018
* Autor: A01206194 Marco Mancha
*
*--------------------------------------------------------------*/

#include "header.h"
#include <string.h>
#include <time.h>

struct info {
	int nsfd;
	struct sockaddr_in client_info;
};

char *ip_c;
char *base;

pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;

void send_msg(int sfd, int code, char* data) {
	long length = strlen(data);
	printf("Enviando codigo: %i lenght = %li text = %s\n",code,length,data);
	write(sfd, &code, sizeof(code));
	write(sfd, &length, sizeof(length));
	write(sfd, data, length * sizeof(char));
}

void send_msg_file(int sfd, int code, char* data, long length) {
	printf("Enviando codigo: %i lenght = %li text = %s\n",code,length,data);
	write(sfd, &code, sizeof(code));
	write(sfd, &length, sizeof(length));
	write(sfd, data, length * sizeof(char));
}

void establece_conexion(){
	FILE* file;
	time_t t = time(NULL);
	struct tm tm = *localtime(&t);
	pthread_mutex_lock(&mutex);
	file = fopen("arch.log", "a");
	if (!file) {
		perror("arch.log");
		exit(-1);
	}
	fprintf(file,"Conection time: %d-%d-%d %d:%d:%d Conexion establecida con: %s\n", tm.tm_year + 1900, tm.tm_mon + 1, tm.tm_mday, tm.tm_hour, tm.tm_min, tm.tm_sec, ip_c);
	fclose(file);
	pthread_mutex_unlock(&mutex);
}

void escribe_conexion(int code, char* dataa){
	FILE* file;
	time_t t = time(NULL);
	struct tm tm = *localtime(&t);
	pthread_mutex_lock(&mutex);
	file = fopen("arch.log", "a");
	if (!file) {
		perror("arch.log");
		exit(-1);
	}
	fprintf(file,"Conection time: %d-%d-%d %d:%d:%d IP: %s Comando recibido: %i Parametro: %s\n", tm.tm_year + 1900, tm.tm_mon + 1, tm.tm_mday, tm.tm_hour, tm.tm_min, tm.tm_sec, ip_c, code,dataa);
	fclose(file);
	pthread_mutex_unlock(&mutex);
}

void escribe_resultado(int code, char* dataa){
	FILE* file;
	time_t t = time(NULL);
	struct tm tm = *localtime(&t);
	pthread_mutex_lock(&mutex);
	file = fopen("arch.log", "a");
	if (!file) {
		perror("arch.log");
		exit(-1);
	}
	fprintf(file,"Conection time: %d-%d-%d %d:%d:%d IP: %s Comando enviado: %i Mensaje: %s\n",tm.tm_year + 1900, tm.tm_mon + 1, tm.tm_mday, tm.tm_hour, tm.tm_min, tm.tm_sec,ip_c, code,dataa);
	fclose(file);
	pthread_mutex_unlock(&mutex);
}

void envia_directorio(char *directorio, int nsfd){
	DIR* dir;
	struct dirent* direntry;
	struct stat info;
	char current[PATH_MAX + NAME_MAX + 1];
	char filepath[PATH_MAX + NAME_MAX + 1];
	char filename[PATH_MAX + NAME_MAX + 1];
	int found = 0,j,acum;
	char* token;
	char* split[10];

	getcwd(current, NAME_MAX);
	strcat(current,base);
	if( directorio[0] != '/' || strstr(directorio, "..") != NULL){
		send_msg(nsfd,ERROR_INTERNO,"Error Interno");
		escribe_resultado(ERROR_INTERNO,"Error Interno");
		return;
	}
	printf("BUSCANDO: %s\n",directorio);
	if(strcmp("/",directorio) != 0){
		token = strtok(directorio, "/");
		j = 0;
		while (token != NULL)
		{
				split[j] = token;
				token = strtok(NULL, "/");
				j++;
				acum = j;
		}
		j = 0;
		if(acum > 1){
			strcat(current,"/");
			while(j < acum -1){
					strcat(current,split[j]);
					split[j] = "";
				j++;
			}
		}
		sprintf(filename, "%s/%s", current, split[acum-1]);
		split[acum-1] = "";
	}else{
		sprintf(filename, "%s/", current);
		send_msg(nsfd,ENVIANDO_CONTENIDO_DIRECTORIO,filename);
		escribe_resultado(ENVIANDO_CONTENIDO_DIRECTORIO,filename);
		return;
	}
	free(token);
	if ( (dir = opendir(current)) == NULL ) {
		printf("VALOR ACUM: %i\n",acum);
		printf("TRATANDO DE ABRIR: %s\n",current);
		printf("LAST: %s\n",split[acum-1]);
		printf("Error abriendo directorio actual dir\n");
	}
	while ( (direntry = readdir(dir)) != NULL ) {
		if (strcmp(direntry->d_name, ".") != 0 && strcmp(direntry->d_name, "..") != 0) {
			sprintf(filepath, "%s/%s", current, direntry->d_name);
			if (strcmp(filename,filepath) == 0) {
				found = 1;
				lstat(filename, &info);
				if(info.st_mode & S_IRUSR){
					if(S_ISREG(info.st_mode)) {
						send_msg(nsfd,RUTA_NO_DIRECTORIO,"Ruta no es directorio");
						escribe_resultado(RUTA_NO_DIRECTORIO,"Ruta no es directorio");
						closedir(dir);
						return;
					}else{
						send_msg(nsfd,ENVIANDO_CONTENIDO_DIRECTORIO,filename);
						escribe_resultado(ENVIANDO_CONTENIDO_DIRECTORIO,filename);
						closedir(dir);
						return;
					}
				}
				else{
					send_msg(nsfd,PERMISO_DENEGADO,"Permiso Denegado");
					escribe_resultado(PERMISO_DENEGADO,"Permiso Denegado");
					closedir(dir);
					return;
				}
			}
		}
	}

	if(found == 0){
		send_msg(nsfd,DIRECTORIO_NO_ENCONTRADO,"Directorio no encontrado");
		escribe_resultado(DIRECTORIO_NO_ENCONTRADO,"Directorio no encontrado");
	}
	closedir(dir);
}

void envia_archivo(char *archivo, int nsfd){
	DIR* dir;
	FILE* f;
	struct dirent* direntry;
	struct stat info;
	char current[PATH_MAX + NAME_MAX + 1];
	char filepath[PATH_MAX + NAME_MAX + 1];
	char filename[PATH_MAX + NAME_MAX + 1];
	int found = 0,j,acum;
	char buffer[4];
	char *token;
	char *split[10];

	getcwd(current, NAME_MAX);
	strcat(current,base);
	if( archivo[0] != '/' || strstr(archivo, "..") != NULL){
		send_msg(nsfd,ERROR_INTERNO,"Error Interno");
		escribe_resultado(ERROR_INTERNO,"Error Interno");
		return;
	}
	printf("BUSCANDO: %s\n",archivo);
	if(strcmp("/",archivo) != 0){
		token = strtok(archivo, "/");
		j = 0;
		while (token != NULL)
		{
				split[j] = token;
				token = strtok(NULL, "/");
				j++;
				acum = j;
		}
		j = 0;
		if(acum > 1){
			while(j < acum -1){
					strcat(current,"/");
					if( strchr(split[j], '.') == NULL){
							strcat(current,split[j]);
					}
					split[j] = "";
					j++;
			}
		}
		sprintf(filename, "%s/%s", current, split[acum-1]);
		split[acum-1] = "";
	}else{
		sprintf(filename, "%s/", current);
	}
	free(token);

	if ( (dir = opendir(current)) == NULL ) {
		printf("VALOR ACUM: %i\n",acum);
		printf("TRATANDO DE ABRIR: %s\n",current);
		printf("LAST: %s",split[acum-1]);
		printf("BUSCANDO: %s\n",archivo);
		printf("Error abriendo arch %s\n",current);
	}

	while ( (direntry = readdir(dir)) != NULL ) {
		if (strcmp(direntry->d_name, ".") != 0 && strcmp(direntry->d_name, "..") != 0) {
			sprintf(filepath, "%s/%s", current, direntry->d_name);
			if (strcmp(filename, filepath) == 0) {
				found = 1;
				lstat(filename, &info);
				if(info.st_mode & S_IRUSR){
					if(S_ISDIR(info.st_mode)) {
						send_msg(nsfd,RUTA_ES_DIRECTORIO,"Ruta es directorio");
						escribe_resultado(RUTA_ES_DIRECTORIO,"Ruta es directorio");
						closedir(dir);
						return;
					}else{
						f = fopen(filename, "rb");
						if (!f) {
							printf("Error abriendo archivo especificado\n");
							exit(-1);
						}
						fseek(f, 0, SEEK_END);
						long fsize = ftell(f);
						fseek(f, 0, SEEK_SET);

						char *string = (char *) malloc(fsize);
						fread(string,1, fsize, f);
						fclose(f);
						send_msg_file(nsfd,ENVIANDO_ARCHIVO,string,fsize);
						free(string);
						escribe_resultado(ENVIANDO_ARCHIVO,filename);
						closedir(dir);
						return;
					}
				}
				else{
					send_msg(nsfd,PERMISO_DENEGADO,"Permiso Denegado");
					escribe_resultado(PERMISO_DENEGADO,"Permiso Denegado");
					closedir(dir);
					return;
				}
			}
		}
	}
	if(found == 0){
		send_msg(nsfd,ARCHIVO_NO_ENCONTRADO,"Archivo no encontrado");
		escribe_resultado(ARCHIVO_NO_ENCONTRADO,"Archivo no encontrado");
	}
	closedir(dir);
}

void* serves_client(void *param) {
	int nsfd = *( (int*) param);
	int code;
	long length,size;

	send_msg(nsfd, HOLA, "hola");
	establece_conexion();
	escribe_resultado(HOLA, "hola");

	do {
		char* data;
		length = 0;
		code = 0;
		read(nsfd, &code, sizeof(code));
		read(nsfd, &length, sizeof(length));
		data = (char*) malloc((length + 1) * sizeof(char));
		read(nsfd, data, length * sizeof(char));
		data[length] = '\0';
		printf("Recibiendo codigo: %i lenght = %li text = %s \n",code,length,data);
		switch(code){
			case ENVIO_ARCHIVO:
				envia_archivo(data, nsfd);
				break;
			case DESPLEGAR_DIRECTORIO:
				envia_directorio(data, nsfd);
				break;
			case FIN_CONEXION:
				escribe_resultado(FIN_CONEXION, "Fin de conexion");
				printf("\nFIN DE CONEXION\n");
				break;
			default:
				send_msg(nsfd, COMANDO_NO_CONOCIDO, "Comando Desconocido");
				escribe_resultado(COMANDO_NO_CONOCIDO, "Comando Desconocido");
				break;
			}
			free(data);
	} while (code != FIN_CONEXION);
	close(nsfd);
}

void server(char* ip, int port, char* program) {
	int sfd, pid;
	struct sockaddr_in server_info;
	pthread_t thread_id;

	if ( (sfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 ) {
		perror(program);
		exit(-1);
	}

	server_info.sin_family = AF_INET;
	server_info.sin_addr.s_addr = inet_addr(ip);
	server_info.sin_port = htons(port);
	if ( bind(sfd, (struct sockaddr *) &server_info, sizeof(server_info)) < 0 ) {
		perror(program);
		exit(-1);
	}

	listen(sfd, 1);
	while (1) {
		int *nsfd = (int *) malloc(sizeof(int));
		struct info *b = (struct info* ) malloc(sizeof(struct info));
		int len = sizeof(b->client_info);
		if ( (b->nsfd = accept(sfd, (struct sockaddr *) &b->client_info, &len)) < 0 ) {
			perror(program);
			exit(-1);
		}
		*nsfd = b->nsfd;
		ip_c = inet_ntoa(b->client_info.sin_addr);
		pthread_create(&thread_id, NULL, serves_client, (void *) nsfd);
	}

}

int main(int argc, char* argv[]) {
	char ip[15];
	int port;

	strcpy(ip, DEFAULT_IP);
	port = DEFAULT_PORT;
	if (argc == 2) {
		base = argv[1];
	}else{
		printf("usage: %s root_dir\n", argv[0]);
		return -1;
	}

	server(ip, port, argv[0]);

	return 0;
}
